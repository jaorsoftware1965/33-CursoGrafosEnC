// ---------------------------------------
// Tutorial de Grafos en C
// Conceptos Generales
// ---------------------------------------

// ---------------------------------------
// Conceptos Generales
// ---------------------------------------


// El origen de la palabra grafo es griego y su significado etimológico es "trazar".

// Los grafos no son más que la versión general de un árbol, es decir, cualquier nodo 
// de un grafo puede apuntar a cualquier otro nodo de éste (incluso a él mismo). 

// Este tipo de estructuras de datos tienen una característica que lo diferencia de 
// las estructuras que hemos visto hasta ahora: los grafos se usan para almacenar 
// datos que están relacionados de alguna manera mas especifica que un simple
// criterio de ordenamiento (relaciones de parentesco, puestos de trabajo, etc.)

// Terminología de grafos: 

// Vértice    : Nodo.
// Enlace     : Conexión entre dos vértices (nodos). El Apuntador a otro nodo
//              Inclusive a si mismo

// Adyacencia : Se dice que dos vértices son adyacentes si entre ellos hay un enlace 
//              directo.

// Vecindad   : Conjunto de vértices adyacentes a otro.

// Camino     : Conjunto de vértices que hay que recorrer para llegar desde un vertice 
//              origen hasta uno destino.

// Grafo conectado : Aquél que tiene camino directo entre todos los nodos.(Completo)
// Grafo dirigido  : Aquél cuyos enlaces son unidireccionales e indican hacia donde 
//                   están dirigidos.

// Grafo con pesos : Aquél cuyos enlaces tienen asociado un valor. En general en este 
//                   tipo de grafos no suele tener sentido que un nodo se apunte a sí 
//                   mismo porque el coste de este enlace sería nulo.

// Ejemplo de Grafo

//         455                  280          304
// Coruña -------- Valladolid ------ Bilbao ----- Oviedo
//   |                 | |
//   |171              | |
//   |        356      | |   193             403
//  Vigo --------------- ----------- Madrid ----- Badajoz


//  Vertices : Coruña, Valladolid, Bilbao, Oviedo, Vigo, Nadrid, Badajoz
//  Enlace   : De Coruña a Madrid con un Peso de 455
//  Camino   : Vigo, Valladolid, Madrid
//  Vecindad : Valladolid y Vigo son Vecindad de Coruña

//  No es un grafo conectado porque no hay un camino directo entre todos los
//  vertices
//  No es un grafo dirigido porque los enlaces son de ida y vuelta
//  Es un grafo con Peso


