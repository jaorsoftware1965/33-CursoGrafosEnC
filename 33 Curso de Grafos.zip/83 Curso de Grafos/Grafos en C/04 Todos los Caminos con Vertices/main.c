// -------------------------------------------------------
// Tutorial de Grafos en C
// Algoritmo de JAOR para encontrar todos los caminos de
// un vertice a todos los demás inclyendo el despliegue de 
// los vértices visitads
// -------------------------------------------------------

//           4                  2             5
// Coruña -------- Valladolid ------ Bilbao ----- Oviedo
//   |                 | |                           
//   |6                | |
//   |        3        | |     9              7
//  Vigo --------------- ----------- Madrid ----- Badajoz


// Matriz de Adyacencia del Grafo
//                  Coruña  Valladolid   Bilbao   Oviedo    Vigo   Madrid  Badajoz
//  Coruña                      4                            6           
//  Valladolid         4                   2                 3        9     
//  Bilbao                      2                   5      
//  Oviedo                                 5         
//  Vigo               6        3                             
//  Madrid                      9                                            7
//  Badajoz                                                           7       

// Rutas Posibles para Coruña (12)
// Coruña (4) Valladolid ->  4
// Coruña (4) Valladolid (2) Bilbao ->  6
// Coruña (4) Valladolid (2) Bilbao (5) Oviedo  -> 11
// Coruña (4) Valladolid (3) Vigo   ->  7
// Coruña (4) Valladolid (9) Madrid ->  13
// Coruña (4) Valladolid (9) Madrid (7) Badajoz -> 20
// Coruña (6) Vigo -> 6
// Coruña (6) Vigo (3) Valladolid -> 9
// Coruña (6) Vigo (3) Valladolid (2) Bilbao -> 11
// Coruña (6) Vigo (3) Valladolid (2) Bilbao (5) Oviedo  -> 16
// Coruña (6) Vigo (3) Valladolid (9) Madrid -> 18
// Coruña (6) Vigo (3) Valladolid (9) Madrid (7) Badajoz -> 25

// Incluimos librerias
#include "stdio.h"
#include "stdlib.h"
#include "string.h"

// Constantes
#define  MAX_VERTICES  7
#define  MAX_CADENA   50
#define  SI_VISITADO  '*'
#define  NO_VISITADO  ' '
#define  KM_MINIMO     0

// Variables globales
int verticesVisitados = -1;

// Estructuras de Vertices
struct vertice
{
    // Nombre
    char nombre[MAX_CADENA];

    // Valor
    int valor;
}arrVerticesVisitados[MAX_VERTICES];


// Arreglo para los vertices
char vertices[MAX_VERTICES][MAX_CADENA];

// Arreglo de Visitados
char visitados[MAX_VERTICES]; // '*'-Si ' '-No

// Matriz de Adyacencia
int  matrizAdyacencia[MAX_VERTICES][MAX_VERTICES];

// Función para inicializar visitados
void fnInicializaVisitados();

// Función para encontrar Destinos de una Ciudad
void fnDestinos(char ciudad[], int valor, int valorAcumulado);

// Función para encontrar índice de la Ciudad
int  fnIndiceCiudad(char ciudad[]);

// Inicializa los vertices visitados
void fnInicializaVerticesVisitados();

// Función para colocar la ciudad en vertices visitados
void fnColocarCiudadEnVerticesVisitados(char ciudad[], int valor);

// Función para eliminar ciudad en vertices visitados
void fnEliminarCiudadEnVerticesVisitados();

// Función para imprimir vertices visitados
void fnImprimirVerticesVisitados();


// Función Principal
int main()
{
    // Variable para indices
    int indice1;
    int indice2;   

    // Estableciendo los Vertices
    strcpy(vertices[0],"Coruna");
    strcpy(vertices[1],"Valladolid");
    strcpy(vertices[2],"Bilbao");
    strcpy(vertices[3],"Oviedo");
    strcpy(vertices[4],"Vigo");
    strcpy(vertices[5],"Madrid");
    strcpy(vertices[6],"Badajoz");
    
    
    // Establecemos los datos de la Matriz de Adyacencia
    // Coruña
    matrizAdyacencia[0][0] = 0;
    matrizAdyacencia[0][1] = 4;
    matrizAdyacencia[0][2] = 0;
    matrizAdyacencia[0][3] = 0;
    matrizAdyacencia[0][4] = 6;
    matrizAdyacencia[0][5] = 0;
    matrizAdyacencia[0][6] = 0;

    // Valladolid
    matrizAdyacencia[1][0] = 4;
    matrizAdyacencia[1][1] = 0;
    matrizAdyacencia[1][2] = 2;
    matrizAdyacencia[1][3] = 0;
    matrizAdyacencia[1][4] = 3;
    matrizAdyacencia[1][5] = 9;
    matrizAdyacencia[1][6] = 0;

    // Bilbao
    matrizAdyacencia[2][0] = 0;
    matrizAdyacencia[2][1] = 2;
    matrizAdyacencia[2][2] = 0;
    matrizAdyacencia[2][3] = 5;
    matrizAdyacencia[2][4] = 0;
    matrizAdyacencia[2][5] = 0;
    matrizAdyacencia[2][6] = 0;

    // Oviedo
    matrizAdyacencia[3][0] = 0;
    matrizAdyacencia[3][1] = 0;
    matrizAdyacencia[3][2] = 5;
    matrizAdyacencia[3][3] = 0;
    matrizAdyacencia[3][4] = 0;
    matrizAdyacencia[3][5] = 0;
    matrizAdyacencia[3][6] = 0;

    // Vigo
    matrizAdyacencia[4][0] = 6;
    matrizAdyacencia[4][1] = 3;
    matrizAdyacencia[4][2] = 0;
    matrizAdyacencia[4][3] = 0;
    matrizAdyacencia[4][4] = 0;
    matrizAdyacencia[4][5] = 0;
    matrizAdyacencia[4][6] = 0;

    // Madrid
    matrizAdyacencia[5][0] = 0;
    matrizAdyacencia[5][1] = 9;
    matrizAdyacencia[5][2] = 0;
    matrizAdyacencia[5][3] = 0;
    matrizAdyacencia[5][4] = 0;
    matrizAdyacencia[5][5] = 0;
    matrizAdyacencia[5][6] = 7;

    // Badajoz
    matrizAdyacencia[6][0] = 0;
    matrizAdyacencia[6][1] = 0;
    matrizAdyacencia[6][2] = 0;
    matrizAdyacencia[6][3] = 0;
    matrizAdyacencia[6][4] = 0;
    matrizAdyacencia[6][5] = 7;
    matrizAdyacencia[6][6] = 0;


     // Imprimos el Grafo
    // Dejamos los espacios para los vertices en los renglones
    printf("%11s"," ");
    for (indice1=0; indice1<MAX_VERTICES;indice1++)
    {
        printf("%11s",vertices[indice1]);
    }
    
    // Deja un Renglon
    printf("\n");

    // Ciclo para imprimir los datos de la matriz
    for (indice1=0; indice1 < MAX_VERTICES; indice1++)
    {
        // Imprime el Vertice
        printf("%-11s",vertices[indice1]);
        for (indice2=0; indice2 < MAX_VERTICES; indice2++)
        {
            if (matrizAdyacencia[indice1][indice2]>KM_MINIMO)
               // imprime los kilómetros
               printf("%11d",matrizAdyacencia[indice1][indice2]);
            else
               // imprime vacio
               printf("%11s"," ");            
        }
        // Deja un Renglon
        printf("\n");
    }

    // Deja un Renglon
    printf("\n");       
    

    // Ciclo para encontrar los destinos de todos los vertice
    for (indice1=0; indice1<MAX_VERTICES;indice1++)
    {
        // Inicializa visitados
        fnInicializaVisitados();

        // Buscamos destinos de Coruña
        fnDestinos(vertices[indice1],0,0);

        // Pausamos
        printf("Pulse enter para continuar ...");
        gets();
        
        // Deja un Renglon
        printf("\n");
    }
    

    // Finaliza
    return 0;
}


// Función para inicializar visitados
void fnInicializaVisitados()
{
    // Variable par ciclo
    int indice;

    // Ciclo para inicializa
    for (indice=0; indice<MAX_VERTICES; indice++)
    {
        // Espacio en Blanco
        visitados[indice]=NO_VISITADO;
    }
}

// Función para encontrar Destinos de una Ciudad
void fnDestinos(char ciudad[], int valor, int valorAcumulado)
{
    // Variable para indice
    int indice;

    // Indice de la Ciudad
    int indiceCiudad;

    // Obtiene el Indice de la Ciudad
    indiceCiudad = fnIndiceCiudad(ciudad);

    // La coloca como visitado
    visitados[indiceCiudad] = SI_VISITADO;

    // Verifica si el valor es 0
    if (valorAcumulado==0)
       // Imprime solo la ciudad
       printf("Buscando destinos de: %-10s\n",ciudad);
    else   
    {
       // Imprime Vertices Visitados
       fnImprimirVerticesVisitados();

       // Imprime el Valor y la Ciudad
       printf("%s -> %d \n",ciudad, valorAcumulado);
    }
    

    // Agrega a visitados
    fnColocarCiudadEnVerticesVisitados(ciudad,valor);
       

    // Ciclo para buscar vecindades y procesarlas
    for (indice=0; indice<MAX_VERTICES; indice++)   
    {
        // Verifica si es una vecindad
        if(matrizAdyacencia[indiceCiudad][indice] > KM_MINIMO)
        {
            // Verifica que no esté visitada
            if (visitados[indice]==NO_VISITADO)
               // Llama recursivamente
               fnDestinos(vertices[indice],matrizAdyacencia[indiceCiudad][indice], matrizAdyacencia[indiceCiudad][indice]+valorAcumulado);
        }
    }

    // La coloca como No visitado al terminar
    visitados[indiceCiudad] = NO_VISITADO;

    // La quita de visitados
    fnEliminarCiudadEnVerticesVisitados();
    
    
    // Verifica si ya termino
    if (valorAcumulado==0)
       printf("Fin de busqueda ...\n");
}

// Obtiene el indice de la ciudad
int fnIndiceCiudad(char ciudad[])
{
    // Variable de resultado
    int resultado = -1;

    // Variable para el indice
    int indice;

    // Variable para el ciclo
    for (indice=0; indice < MAX_VERTICES; indice++)
    {
        // Compara
        if (strcmp(ciudad,vertices[indice])==0)
        {
            // Coloca el indice en el resultado y sale
            resultado = indice;
            break;
        }   
    }

    // Retorna
    return resultado;
}


// Inicializa los vertices visitados
void fnInicializaVerticesVisitados()
{
    // Variable para ciclo
    int indice;

    // Ciclo para inciailizar
    for (indice=0; indice < MAX_VERTICES; indice++)
    {
        // Inicializa
        strcpy(arrVerticesVisitados[indice].nombre,"");
        arrVerticesVisitados[indice].valor=-1;
    }

}

// Función para colocar la ciudad en vertices visitados
void fnColocarCiudadEnVerticesVisitados(char ciudad[], int valor)
{
    // Incrementa el indice
    verticesVisitados++;

    // Coloca los datos
    strcpy(arrVerticesVisitados[verticesVisitados].nombre,ciudad);
    arrVerticesVisitados[verticesVisitados].valor=valor;
}

// Función para eliminar ciudad en vertices visitados
void fnEliminarCiudadEnVerticesVisitados()
{
    // Coloca los datos
    strcpy(arrVerticesVisitados[verticesVisitados].nombre,"");
    arrVerticesVisitados[verticesVisitados].valor=-1;

    // Decrementa el indice
    verticesVisitados--;
}

// Función para imprimir vertices visitados
void fnImprimirVerticesVisitados()
{
    // Variable indice
    int indice;

    // Ciclo para imprimir los vertices
    for (int indice=0; indice<=verticesVisitados; indice++)
    {
        // Imprime
        printf("(%2d) %s ",arrVerticesVisitados[indice].valor,arrVerticesVisitados[indice].nombre);
    }    
    // Cambia de linea
    //printf("\n");
}
