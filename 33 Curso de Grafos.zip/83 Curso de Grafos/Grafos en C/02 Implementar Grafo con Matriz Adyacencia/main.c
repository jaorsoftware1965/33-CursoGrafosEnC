// -------------------------------------------------------
// Tutorial de Grafos en C
// Matriz de Adyacencia
// -------------------------------------------------------

// Representación por matriz de adyacencia

// Es la forma más común de representación y la más directa. 

// Consiste en una matriz de tamaño N x N, en donde:
// a) N es el número de vértices del gráfo
// b) matriz[i][j] tendrá como valor 1  si existe una arista del nodo i al nodo j. 
// c) en caso contrario, el valor será 0. 

// Cuando se trata de grafos ponderados (con peso en los enlaces) en lugar de 1 el 
// valor que tomará será el peso de la arista. 

// Si el grafo es no dirigido hay que asegurarse de que se marca 
// con un 1 (o con el peso) tanto la entrada a[i][j] como la entrada a[j][i], 
// puesto que se puede recorrer en ambos sentidos.

//         455                  280          304
// Coruña -------- Valladolid ------ Bilbao ----- Oviedo
//   |                 | |
//   |171              | |
//   |        356      | |   193             403
//  Vigo --------------- ----------- Madrid ----- Badajoz


// Matriz de Adyacencia del Grafo

//                  Coruña  Valladolid   Bilbao   Oviedo    Vigo   Madrid  Badajoz
//  Coruña                     356                           171           
//  Valladolid        356                  280               171     193      
//  Bilbao                     280                  304
//  Oviedo                                 304
//  Vigo              171      356            
//  Madrid                     193                                           403
//  Badajoz                                                          403


// Incluimos librerias
#include "stdio.h"
#include "stdlib.h"

// Constantes
#define  MAX_VERTICES  7
#define  MAX_CADENA   50

// Arreglo para los vertices
char vertices[MAX_VERTICES][MAX_CADENA];

// Matriz de Adyacencia
int  matrizAdyacencia[MAX_VERTICES][MAX_VERTICES];

// función para liberar el buffer de los enter del scanf
void flush() 
{
    // Verifica que sea diferente de enter
	while (getchar() != '\n');
}

// Función Principal
int main()
{
    // Variable para indices
    int indice1;
    int indice2;   

    // Mensaje
    printf("Captura de 7 Vertices del Grafo\n");

    // Ciclo para capturar los Vertices
    for (indice1=0; indice1 < MAX_VERTICES; indice1++)
    {
        // Mensaje de Captura
        printf("Favor de Capturar el vertice %d:",indice1 + 1);

        // Captura el Vertice
        gets(vertices[indice1]);
    }
    // Dejamos un Espacio
    printf("\n");     

    // Ciclo para indicar adyacencia
    for (indice1=0; indice1 < MAX_VERTICES; indice1++)
    {
        // Ciclo interno
        for (indice2=0; indice2 < MAX_VERTICES; indice2++)
        {
            // Verifica que indice1 e indice2 son distintos
            if (indice1!=indice2)
            {
                // Pregunta de ida
                printf("Kilometros entre [%s] y [%s]:",vertices[indice1],vertices[indice2]);
                
                // Leemos
                scanf("%d",&matrizAdyacencia[indice1][indice2]);
            }
            else
            {
                // Asigna 0 cuando es a si mismo
                matrizAdyacencia[indice1][indice2]=0;
            }
            

        }   
        // Deja un Renglon
        printf("\n");     
    }    

    // Libera el buffet del teclado dejado por los scanf
    flush();
    
    // Mensaje
    printf("Presione enter para continuar y ver la matriz del grafo impreso ...\n");
    gets();
    

    // Imprimos el Grafo
    // Dejamos los espacios para los vertices en los renglones
    printf("          ");
    for (indice1=0; indice1<MAX_VERTICES;indice1++)
    {
        printf("%10s",vertices[indice1]);
    }
    
    // Deja un Renglon
    printf("\n");

    // Ciclo para imprimir los datos de la matriz
    for (indice1=0; indice1 < MAX_VERTICES; indice1++)
    {
        // Imprime el Vertice
        printf("%-10s",vertices[indice1]);
        for (indice2=0; indice2 < MAX_VERTICES; indice2++)
        {
            // Verifica mayor que 0
            if (matrizAdyacencia[indice1][indice2]>0)
               // imprime los kilómetros
               printf("%10d",matrizAdyacencia[indice1][indice2]);
            else
               // imprime espacios
               printf("          ");   
        }
        // Deja un Renglon
        printf("\n");
    }

    // Deja un Renglon
    printf("\n");

    // Mensaje 
    printf("Presione enter para continuar y ver las Vecindades de cada vertice ...\n");
    gets();

    
    // Ciclo para desplegar las Vecindades de Cada Vertice
    for (indice1=0; indice1 < MAX_VERTICES; indice1++)
    {        
        // Mensaje de Vecindad
        printf("Vecindad de %s:\n",vertices[indice1]);

        // Ciclo interno
        for (indice2=0; indice2 < MAX_VERTICES; indice2++)
        {
            // Verifica que indice1 e indice2 son distintos
            if (indice1!=indice2)
            {
                // Verifica que sea mayor que 0
                if (matrizAdyacencia[indice1][indice2]>0)
                {
                    // Despliega el Vertice adyacente
                    printf("%s-%d\n",vertices[indice2],matrizAdyacencia[indice1][indice2]);
                }                
            }            
        }
        
        // Mensaje
        printf("Presione enter para continuar ...\n");
        gets();

        // Deja un Renglon
        printf("\n");
        
    }

    // Mensaje Final
    printf("Programa Terminado ...\n");

    // Finaliza
    return 0;
}
